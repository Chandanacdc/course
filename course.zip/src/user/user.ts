export class User{
constructor(
public firstName ='',
public lastName ='',
public username ='',
public password='',
public confirm='',
public sendNewCourseMail='',
public email='',
public days='')

{}


}
   