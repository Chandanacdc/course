export interface CourseListInterface{
    courseImg:string;
    courseName:string;
    courseTrainner:string;
    coursePrice:number;
    courseRating:number;
    Mentor:string;
    category:string;
}